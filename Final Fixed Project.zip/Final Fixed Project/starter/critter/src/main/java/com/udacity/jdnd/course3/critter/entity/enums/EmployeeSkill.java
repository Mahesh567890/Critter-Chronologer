package com.udacity.jdnd.course3.critter.entity.enums;

public enum EmployeeSkill {
    PETTING,
    WALKING,
    FEEDING,
    SHAVING
}
