package com.udacity.jdnd.course3.critter.service;

import com.udacity.jdnd.course3.critter.entity.Employee;
import com.udacity.jdnd.course3.critter.entity.enums.DayOfWeek;
import com.udacity.jdnd.course3.critter.entity.enums.EmployeeSkill;
import com.udacity.jdnd.course3.critter.repository.EmployeeRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;

    public EmployeeService(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    // ✅ REQUIRED BY UserController
    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    // ✅ REQUIRED BY UserController
    public Employee getEmployee(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found"));
    }

    // ✅ REQUIRED BY UserController
    public void setAvailability(Set<java.time.DayOfWeek> days, Long employeeId) {
        Employee employee = getEmployee(employeeId);

        Set<DayOfWeek> converted = days.stream()
                .map(d -> DayOfWeek.valueOf(d.name()))
                .collect(Collectors.toSet());

        employee.setDaysAvailable(converted);
        employeeRepository.save(employee);
    }

    // ✅ REQUIRED BY Functional Tests
    public List<Employee> findEmployeesForService(LocalDate date, Set<EmployeeSkill> skills) {
        DayOfWeek day = DayOfWeek.valueOf(date.getDayOfWeek().name());

        return employeeRepository.findByDaysAvailableContaining(day)
                .stream()
                .filter(e -> e.getSkills().containsAll(skills))
                .collect(Collectors.toList());
    }
}
