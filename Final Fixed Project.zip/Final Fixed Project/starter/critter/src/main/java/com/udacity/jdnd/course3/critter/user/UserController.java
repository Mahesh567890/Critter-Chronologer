package com.udacity.jdnd.course3.critter.user;

import com.udacity.jdnd.course3.critter.entity.Customer;
import com.udacity.jdnd.course3.critter.entity.Employee;
import com.udacity.jdnd.course3.critter.entity.Pet;
import com.udacity.jdnd.course3.critter.entity.enums.DayOfWeek;
import com.udacity.jdnd.course3.critter.service.CustomerService;
import com.udacity.jdnd.course3.critter.service.EmployeeService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/user")
public class UserController {

    private final CustomerService customerService;
    private final EmployeeService employeeService;

    public UserController(CustomerService customerService,
                          EmployeeService employeeService) {
        this.customerService = customerService;
        this.employeeService = employeeService;
    }



    @PostMapping("/customer")
    public CustomerDTO saveCustomer(@RequestBody CustomerDTO dto) {
        Customer customer = new Customer();
        customer.setName(dto.getName());
        customer.setPhoneNumber(dto.getPhoneNumber());
        customer.setNotes(dto.getNotes());

        return convertCustomer(customerService.saveCustomer(customer));
    }

    @GetMapping("/customer")
    public List<CustomerDTO> getAllCustomers() {
        return customerService.getAllCustomers()
                .stream()
                .map(this::convertCustomer)
                .collect(Collectors.toList());
    }

    @GetMapping("/customer/pet/{petId}")
    public CustomerDTO getOwnerByPet(@PathVariable Long petId) {
        return convertCustomer(customerService.getOwnerByPet(petId));
    }


    @PostMapping("/employee")
    public EmployeeDTO saveEmployee(@RequestBody EmployeeDTO dto) {
        Employee employee = new Employee();
        employee.setName(dto.getName());
        employee.setSkills(dto.getSkills());

        if (dto.getDaysAvailable() != null) {
            employee.setDaysAvailable(
                    dto.getDaysAvailable().stream()
                            .map(d -> DayOfWeek.valueOf(d.name()))
                            .collect(Collectors.toSet())
            );
        }

        return convertEmployee(employeeService.saveEmployee(employee));
    }

    @GetMapping("/employee/{id}")
    public EmployeeDTO getEmployee(@PathVariable Long id) {
        return convertEmployee(employeeService.getEmployee(id));
    }

    @PutMapping("/employee/{id}/availability")
    public void setAvailability(@RequestBody Set<java.time.DayOfWeek> days,
                                @PathVariable Long id) {
        employeeService.setAvailability(days, id);
    }

    @PostMapping("/employee/availability")
    public List<EmployeeDTO> findEmployeesForService(@RequestBody EmployeeRequestDTO dto) {
        return employeeService.findEmployeesForService(dto.getDate(), dto.getSkills())
                .stream()
                .map(this::convertEmployee)
                .collect(Collectors.toList());
    }


    private CustomerDTO convertCustomer(Customer customer) {
        CustomerDTO dto = new CustomerDTO();
        dto.setId(customer.getId());
        dto.setName(customer.getName());
        dto.setPhoneNumber(customer.getPhoneNumber());
        dto.setNotes(customer.getNotes());
        dto.setPetIds(
                customer.getPets()
                        .stream()
                        .map(Pet::getId)
                        .collect(Collectors.toList())
        );
        return dto;
    }

    private EmployeeDTO convertEmployee(Employee employee) {
        EmployeeDTO dto = new EmployeeDTO();
        dto.setId(employee.getId());
        dto.setName(employee.getName());
        dto.setSkills(employee.getSkills());

        if (employee.getDaysAvailable() != null) {
            dto.setDaysAvailable(
                    employee.getDaysAvailable().stream()
                            .map(d -> java.time.DayOfWeek.valueOf(d.name()))
                            .collect(Collectors.toSet())
            );
        }

        return dto;
    }
}
